import os

def rm(filename):
    os.remove(filename)


